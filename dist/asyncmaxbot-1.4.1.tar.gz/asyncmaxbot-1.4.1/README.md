# AsyncMaxBot SDK

[![PyPI version](https://badge.fury.io/py/asyncmaxbot.svg)](https://badge.fury.io/py/asyncmaxbot)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**AsyncMaxBot SDK** — это современная асинхронная Python библиотека для создания ботов в Max Messenger API. Библиотека предоставляет удобный и мощный API для разработки Telegram-подобных ботов с поддержкой всех современных возможностей.

## 🚀 Основные возможности

- ✅ **Полная асинхронность** — построена на `asyncio` и `aiohttp`
- ✅ **MagicFilter система** — гибкая фильтрация в стиле ORM
- ✅ **Inline клавиатуры** — поддержка кнопок и callback-запросов
- ✅ **Middleware система** — сквозная логика обработки
- ✅ **Router система** — модульная архитектура (версия 1.4+)
- ✅ **Полная типизация** — основана на Pydantic моделях
- ✅ **Обработка вложений** — поддержка всех типов файлов
- ✅ **Расширенные события** — обработка системных событий
- ✅ **Встроенные middleware** — логирование, антиспам, метрики

## 📦 Установка

```bash
pip install asyncmaxbot
```

## 🎯 Быстрый старт

```python
import asyncio
from maxbot import Bot, Dispatcher, Context, F

TOKEN = "YOUR_BOT_TOKEN"

async def main():
    async with Bot(token=TOKEN) as bot:
        dp = Dispatcher(bot)
        
        @dp.message_handler(F.command == "start")
        async def start_handler(ctx: Context):
            await ctx.reply(f"👋 Привет, {ctx.user.name}!")
        
        @dp.message_handler()
        async def echo_handler(ctx: Context):
            if ctx.text:
                await ctx.reply(f"📢 {ctx.text}")
        
        print("🤖 Бот запущен!")
        await bot.polling(dispatcher=dp)

if __name__ == "__main__":
    asyncio.run(main())
```

## 📚 Документация

- **[Руководство по API](docs/api.md)** — полное описание всех компонентов
- **[Примеры использования](docs/examples.md)** — рабочие примеры ботов
- **[Примеры в папке examples/](examples/)** — готовые к запуску боты

## 🎮 Примеры ботов

### Эхо-бот
```python
@dp.message_handler(F.command == "start")
async def start_handler(ctx: Context):
    await ctx.reply(f"👋 Привет, {ctx.user.name}!")

@dp.message_handler()
async def echo_handler(ctx: Context):
    if ctx.text:
        await ctx.reply(f"📢 {ctx.text}")
```

### Блэкджек с клавиатурами
```python
from maxbot.max_types import InlineKeyboardMarkup, InlineKeyboardButton

@dp.message_handler(F.command == "start")
async def start_game(ctx: Context):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🃏 Взять", payload="hit")],
            [InlineKeyboardButton(text="✋ Стоп", payload="stand")]
        ]
    )
    await ctx.reply("🎲 Игра началась!", reply_markup=keyboard)

@dp.callback_query_handler(F.payload == "hit")
async def hit_handler(ctx: Context):
    await ctx.answer_callback("🃏 Карта взята!")
    await ctx.edit_message("Новая карта добавлена!")
```

### MagicFilter система
```python
# Простые фильтры
@dp.message_handler(F.text == "привет")
@dp.message_handler(F.user_id == 123)

# Строковые операции
@dp.message_handler(F.text.contains("спасибо"))
@dp.message_handler(F.text.startswith("/"))

# Комбинирование
@dp.message_handler(F.text.contains("admin") & F.user_id == 123)
@dp.message_handler(F.command == "start" | F.text.startswith("help"))

# Работа с вложениями
@dp.message_handler(F.has_attachments == True)
@dp.message_handler(F.attachment.type == "image")
```

## 🔧 Архитектура

### Основные компоненты

- **`Bot`** — основной класс для работы с API
- **`Dispatcher`** — диспетчер обновлений и обработчиков
- **`Context`** — удобный объект для работы с сообщениями
- **`Router`** — модульная архитектура (версия 1.4+)
- **`F` (MagicFilter)** — система фильтрации
- **Middleware** — сквозная логика обработки

### Поток обработки

1. `bot.polling()` получает обновления от API
2. `Dispatcher` передает обновление в middleware
3. Данные парсятся в Pydantic модели
4. Создается объект `Context`
5. Проверяются фильтры обработчиков
6. Вызывается подходящий обработчик

## 🛠️ Middleware

```python
from maxbot.middleware import (
    LoggingMiddleware, 
    ErrorHandlingMiddleware,
    ThrottlingMiddleware,
    UserTrackingMiddleware
)

dp.include_middleware(LoggingMiddleware())
dp.include_middleware(ErrorHandlingMiddleware())
dp.include_middleware(ThrottlingMiddleware(rate_limit=1.0))
```

## 🔌 Router система (версия 1.4+)

```python
from maxbot import Router

# Создаем роутер для команд
commands_router = Router()

@commands_router.message_handler(F.command == "start")
async def start_command(ctx: Context):
    await ctx.reply("Привет!")

# Подключаем к диспетчеру
dp.include_router(commands_router)
```

## 📎 Обработка вложений

```python
@dp.message_handler(F.attachment.type == "image")
async def image_handler(ctx: Context):
    attachment = ctx.attachments[0]
    await ctx.reply(f"🖼️ Получено изображение: {attachment.filename}")

@dp.message_handler(F.has_attachments == True)
async def any_attachment_handler(ctx: Context):
    await ctx.reply("📎 Получено вложение!")
```

## 🎯 Расширенные события (версия 1.4+)

```python
@dp.bot_started_handler()
async def on_bot_started(ctx: Context):
    await ctx.reply(f"🎉 Бот запущен пользователем {ctx.user.name}!")

@dp.user_added_handler()
async def on_user_added(ctx: Context):
    await ctx.reply(f"👋 Добро пожаловать, {ctx.user.name}!")

@dp.chat_member_updated_handler()
async def on_member_updated(ctx: Context):
    await ctx.reply(f"👤 Статус изменен: {ctx.old_status} → {ctx.new_status}")
```

## 📊 Типы данных

Библиотека использует Pydantic для строгой типизации:

```python
from maxbot import User, Chat, Message, BaseAttachment

# Основные модели
user: User          # Пользователь
chat: Chat          # Чат
message: Message    # Сообщение
attachment: BaseAttachment  # Вложение
```

## 🚀 Лучшие практики

### Структура проекта
```
my_bot/
├── main.py          # Точка входа
├── routers/         # Роутеры
│   ├── commands.py
│   ├── callbacks.py
│   └── events.py
├── handlers/        # Обработчики
├── middleware/      # Middleware
└── config.py        # Конфигурация
```

### Организация кода
```python
# routers/commands.py
def create_commands_router():
    router = Router()
    
    @router.message_handler(F.command == "start")
    async def start_handler(ctx: Context):
        await ctx.reply("Привет!")
    
    return router

# main.py
dp.include_router(create_commands_router())
```

## 📈 Версии

- **1.4.0** — Router система, расширенные события
- **1.3.x** — MagicFilter, inline клавиатуры
- **1.2.x** — Middleware система
- **1.1.x** — Базовая функциональность

## 🤝 Вклад в проект

Мы приветствуем вклад в развитие проекта! Пожалуйста, ознакомьтесь с [AI_GUIDE.md](AI_GUIDE.md) для понимания процесса разработки.

### Установка для разработки

```bash
git clone https://github.com/your-repo/asyncmaxbot.git
cd asyncmaxbot
pip install -e .
```

### Запуск тестов

```bash
pytest tests/
```

## 📄 Лицензия

MIT License — см. файл [LICENSE](LICENSE) для подробностей.

## 🔗 Ссылки

- **[Документация](docs/)** — полная документация
- **[Примеры](examples/)** — готовые боты
- **[PyPI](https://pypi.org/project/asyncmaxbot/)** — пакет на PyPI
- **[Issues](https://github.com/your-repo/asyncmaxbot/issues)** — баги и предложения

## ⭐ Поддержка

Если вам нравится проект, поставьте звезду на GitHub! Это помогает проекту развиваться.

---

**AsyncMaxBot SDK** — современный инструмент для создания ботов в Max Messenger API. 🚀